"""Punto de entrada WSGI de la aplicación.

DirectAdmin genera su propio passenger_wsgi.py, que carga el archivo
indicado en «Archivo de inicio de la aplicación» y busca en él el
objeto nombrado en «Punto de entrada».

  Archivo de inicio → wsgi.py
  Punto de entrada  → application

NO llamar a este archivo passenger_wsgi.py: el envoltorio de DirectAdmin
se cargaría a sí mismo en bucle y muere con RecursionError.

Estructura esperada en el servidor:

    passenger_wsgi.py      <- lo genera DirectAdmin, no lo toques
    wsgi.py                <- este archivo
    requirements.txt
    app/
        api.py             <- aquí vive la instancia Flask
        db.py
        .env
"""
import os
import sys

# Se añade app/ al path, no la raíz: api.py importa `db` como módulo de
# nivel superior, así que ese directorio tiene que ser importable.
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'app'))

from api import app as application  # noqa: E402
